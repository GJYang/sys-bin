#define BITS 64
#include "ppc_corenote.c"
