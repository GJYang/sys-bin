#define BITS 64
#include "s390_corenote.c"
