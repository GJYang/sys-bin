#define BITS 32
#include "x86_64_corenote.c"
